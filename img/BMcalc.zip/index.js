const kivant = document.getElementById('kivantKaloria');
const valasztas = document.getElementById('Valaszto');
const TapanyagMennyiseg = document.getElementById('tapanyag');
const cel = document.getElementById('Kcel');
const eredmeny = document.getElementById('eredmeny');
const kell = document.getElementById('kell');
let osszeg = 0;

function Osszegzes(){
    if(valasztas.value == "szenhidrat"){
        osszeg = osszeg + TapanyagMennyiseg.value * 4;
        console.log(osszeg);
    }
    if(valasztas.value == "feherje"){
        osszeg = osszeg + TapanyagMennyiseg.value * 4;
        console.log(osszeg);
    }
    if(valasztas.value == "zsir"){
        osszeg = osszeg + TapanyagMennyiseg.value * 9;
        console.log(osszeg);
    }
}

function ErtekKi(){
    eredmeny.innerHTML = osszeg;
    console.log(osszeg);

    if(kivant.value - osszeg < 0){
        kell.innerHTML = "Már mindegy haver";
    }else{
        kell.innerHTML = kivant.value-osszeg;
    }

    if(osszeg === 0){
        if(valasztas.value == "szenhidrat"){
            eredmeny.innerHTML = TapanyagMennyiseg.value * 4;
        }
        if(valasztas.value == "feherje"){
            eredmeny.innerHTML = TapanyagMennyiseg.value * 4;
        }
        if(valasztas.value == "zsir"){
            eredmeny.innerHTML = TapanyagMennyiseg.value * 9;
        }
    }
}